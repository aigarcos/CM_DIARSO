import { Component } from '@angular/core';

@Component({
  selector: 'app-generar-consulta',
  standalone: true,
  templateUrl: './generar-consulta.component.html',
  styleUrl: './generar-consulta.component.css'
})
export class GenerarConsultaComponent {}
