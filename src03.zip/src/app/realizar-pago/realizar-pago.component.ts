import { Component } from '@angular/core';

@Component({
  selector: 'app-realizar-pago',
  standalone: true,
  templateUrl: './realizar-pago.component.html',
  styleUrl: './realizar-pago.component.css'
})
export class RealizarPagoComponent {}
