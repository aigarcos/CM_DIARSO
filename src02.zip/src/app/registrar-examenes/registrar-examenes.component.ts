import { Component } from '@angular/core';

@Component({
  selector: 'app-registrar-examenes',
  standalone: true,
  templateUrl: './registrar-examenes.component.html',
  styleUrl: './registrar-examenes.component.css'
})
export class RegistrarExamenesComponent {}
